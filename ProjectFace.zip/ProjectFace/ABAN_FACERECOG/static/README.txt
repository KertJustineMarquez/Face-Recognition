Requirements

1. requires 64-bit python

2. install visual studio community 2022 -> Desktop development with C++  

3. type in terminal -> "pip install -r requirements.txt"

4. Run code