Requirements the codes

1. Requires 64-bit python
2. Install IDE (VSCODE recommended)
3. Install Visual Studio Community 2022
4. Install Desktop Development with C++ in the Workloads tab
5. PIP install packages
    - pip install cmake
    - pip install dlib
    - pip install face_recognition
    - pip install numpy
    - pip install opencv-python
6. Run the code. 



