import cv2
import numpy as np
import face_recognition
import os

path = r'C:\Users\RID\Desktop\ProjectFace\ABAN_FACERECOG\Live\faceimages3'
images = []
className = []
myList = os.listdir(path)

for cls in myList:
    currentImage = cv2.imread(os.path.join(path, cls))  # Use os.path.join for better path handling
    images.append(currentImage)
    className.append(os.path.splitext(cls)[0])

def findEncondings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        faceLocations = face_recognition.face_locations(img)
        encodings = face_recognition.face_encodings(img, faceLocations)
        encodeList.extend(encodings)
    return encodeList

encodeListKnown = findEncondings(images)
print('Encoding Complete')

cap = cv2.VideoCapture(0)

while True:
    success, img = cap.read()
    imgSmall = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgSmall = cv2.cvtColor(imgSmall, cv2.COLOR_BGR2RGB)

    faceCurrentFrame = face_recognition.face_locations(imgSmall)
    encodeCurrentFrame = face_recognition.face_encodings(imgSmall, faceCurrentFrame)

    for encodeFace, faceLoc in zip(encodeCurrentFrame, faceCurrentFrame):
        matches = face_recognition.compare_faces(encodeListKnown, encodeFace, tolerance=0.6)
        faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
        matchIndices = np.where(matches)[0]

        for matchIndex in matchIndices:
            name = className[matchIndex].upper()
            y1, x2, y2, x1 = faceLoc
            y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4

            cv2.rectangle(img, (x1, y1), (x2, y2), (0, 0, 255), 2)
            cv2.rectangle(img, (x1, y2 - 35), (x2, y2), (0, 0, 255), cv2.FILLED)
            cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)

    cv2.imshow('Webcam', img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()