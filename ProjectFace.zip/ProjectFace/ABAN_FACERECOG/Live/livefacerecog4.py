# import cv2
# import mediapipe as mp
# import time
# import face_recognition
# import os

# def loadTrainingImages(path):
#     images = []
#     classNames = []
#     myList = os.listdir(path)
#     for cls in myList:
#         currentImage = face_recognition.load_image_file(os.path.join(path, cls))
#         images.append(currentImage)
#         classNames.append(os.path.splitext(cls)[0])
#         print("Loaded", cls, "Class Name", os.path.splitext(cls)[0])
#     return images, classNames

# path = r'C:\Users\RID\Desktop\ProjectFace\ABAN_FACERECOG\Live\faceimages2'
# images, classNames = loadTrainingImages(path)

# # Extract multiple encodings for each training image
# encodeListKnown = []
# for img in images:
#     encodings = face_recognition.face_encodings(img)
#     if encodings:
#         encodeListKnown.extend(encodings)

# print("Encoding complete")

# cap = cv2.VideoCapture(1)
# mpFaceDetection = mp.solutions.face_detection
# faceDetection = mpFaceDetection.FaceDetection(0.75)

# while True:
#     success, img = cap.read()
#     imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
#     results = faceDetection.process(imgRGB)

#     if results.detections:
#         for id, detection in enumerate(results.detections):
#             bboxC = detection.location_data.relative_bounding_box
#             ih, iw, ic = img.shape
#             bbox = int(bboxC.xmin * iw), int(bboxC.ymin * ih), \
#                    int(bboxC.width * iw), int(bboxC.height * ih)

#             # Recognize face using multiple encodings
#             encodeFace = face_recognition.face_encodings(img, [(bbox[1], bbox[2], bbox[1] + bbox[3], bbox[0] + bbox[2])])
#             if encodeFace:
#                 matches = face_recognition.compare_faces(encodeListKnown, encodeFace[0], tolerance=0.6)
#                 name = "Unknown"  # Default name
#                 if True in matches:
#                     matchIndex = matches.index(True)
#                     name = classNames[matchIndex]
#                 cv2.rectangle(img, bbox, (255, 0, 255), 2)
#                 cv2.putText(img, name, (bbox[0], bbox[1]), cv2.FONT_HERSHEY_PLAIN,2, (255, 0, 255), 2)

#     cv2.imshow("Image", img)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()


import cv2
import mediapipe as mp
import time
import face_recognition
import os
import numpy as np


# def loadTrainingImages(path):
#     images = []
#     classNames = []
#     myList = os.listdir(path)
#     for cls in myList:
#         currentImage = face_recognition.load_image_file(os.path.join(path, cls))
#         images.append(currentImage)
#         classNames.append(os.path.splitext(cls)[0])
#         print("Loaded", cls, "Class Name", os.path.splitext(cls)[0])
#     return images, classNames

#initialization of mylist variable to store list directory from path
path = r'C:\Users\RID\Desktop\ProjectFace\ABAN_FACERECOG\Live\faceimages2'

images =[]
className =[]
myList = os.listdir(path)


#loop function to grab image from path which is the image folder 
for cls in myList:
    #variable for reading the path in the folder
    currentImage = cv2.imread(f'{path}/{cls}')
    #appending the images from the folder to the list 'images'
    images.append(currentImage)
    #appending the names of the images from the folder without grabbing the image format
    className.append(os.path.splitext(cls)[0])


def findEncondings(images):
    #initialization of encodeList list
    encodeList = []
    #for loop function of image in image folder
    for img in images:
        #conversion of image to RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        #initialization of encode variable for face recognition face encoding image
        face_encodings = face_recognition.face_encodings(img)
        #to accept multiple images for better accuracy
        if face_encodings:
            encodeList.extend(face_encodings)
        # encodeList.append(face_encodings)
    return encodeList


encodeListKnown = findEncondings(images)



print("Encoding complete")

cap = cv2.VideoCapture(0)
mpFaceDetection = mp.solutions.face_detection
faceDetection = mpFaceDetection.FaceDetection(0.75)

while True:
    success, img = cap.read()
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = faceDetection.process(imgRGB)

    if results.detections:
        for id, detection in enumerate(results.detections):
            bboxC = detection.location_data.relative_bounding_box
            ih, iw, ic = img.shape
            bbox = int(bboxC.xmin * iw), int(bboxC.ymin * ih), \
                   int(bboxC.width * iw), int(bboxC.height * ih)
 
    
            # Recognize face using multiple encodings
            encodeFace = face_recognition.face_encodings(img, [(bbox[1], bbox[2], bbox[1] + bbox[3], bbox[0] + bbox[2])])
            
            if encodeFace:
                
                print("Detected Face Encoding", encodeFace[0])

                for i, known_encoding in enumerate(encodeListKnown):
                    print(f"Known Face {i+1} Encoding: ", known_encoding)
            
                face_distances = face_recognition.compare_faces(encodeListKnown,encodeFace[0])
                
                best_match_index = np.argmin(face_distances)

                if face_distances[best_match_index] <= 0.7:
                    name = className[best_match_index]
                else:
                    name = "Unknown"

                cv2.rectangle(img,bbox, (255,0,255),2)
                cv2.putText(img,name, (bbox[0], bbox[1]), cv2.FONT_HERSHEY_COMPLEX,2,(255,0,255),2)

    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()


# import cv2
# import mediapipe as mp
# import face_recognition
# import os
# import numpy as np

# def loadTrainingImages(path):
#     images = []
#     classNames = []
#     myList = os.listdir(path)
#     for cls in myList:
#         currentImage = face_recognition.load_image_file(os.path.join(path, cls))
#         images.append(currentImage)
#         classNames.append(os.path.splitext(cls)[0])
#         print("Loaded", cls, "Class Name", os.path.splitext(cls)[0])
#     return images, classNames

# def findEncodings(images):
#     encodeList = []
#     for img in images:
#         img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
#         face_encodings = face_recognition.face_encodings(img)
#         if face_encodings:
#             encodeList.extend(face_encodings)
#     return encodeList

# # Load known face images and encode them
# known_images_path = r'C:\Users\RID\Desktop\ProjectFace\ABAN_FACERECOG\Live\faceimages2'
# known_images, classNames = loadTrainingImages(known_images_path)
# encodeListKnown = findEncodings(known_images)

# print("Encoding complete")

# # Initialize webcam capture
# cap = cv2.VideoCapture(0)
# mpFaceDetection = mp.solutions.face_detection
# faceDetection = mpFaceDetection.FaceDetection(0.75)

# while True:
#     success, img = cap.read()
#     imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
#     results = faceDetection.process(imgRGB)

#     if results.detections:
#         for id, detection in enumerate(results.detections):
#             bboxC = detection.location_data.relative_bounding_box
#             ih, iw, ic = img.shape
#             bbox = int(bboxC.xmin * iw), int(bboxC.ymin * ih), \
#                    int(bboxC.width * iw), int(bboxC.height * ih)

#             # Recognize face using multiple encodings
#             encodeFace = face_recognition.face_encodings(img, [(bbox[1], bbox[2], bbox[1] + bbox[3], bbox[0] + bbox[2])])
            
#             if encodeFace:

#                 # Compare with known encodings
#                 face_distances = face_recognition.face_distance(encodeListKnown, encodeFace[0])
#                 best_match_index = np.argmin(face_distances)

#                 if face_distances[best_match_index] <= 0.7:
#                     name = classNames[best_match_index]
#                 else:
#                     name = "Unknown"

#                 cv2.rectangle(img, bbox, (255, 0, 255), 2)
#                 cv2.putText(img, name, (bbox[0], bbox[1]), cv2.FONT_HERSHEY_PLAIN, 2, (255, 0, 255), 2)

#     cv2.imshow("Image", img)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()
