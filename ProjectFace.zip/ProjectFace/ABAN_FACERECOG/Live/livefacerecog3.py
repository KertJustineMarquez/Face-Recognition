# import cv2
# import mediapipe as mp
# import time

# cap = cv2.VideoCapture(0)
# pTime = 0

# mpFaceDetection = mp.solutions.face_detection
# mpDraw = mp.solutions.drawing_utils
# faceDetection = mpFaceDetection.FaceDetection(0.75)

# while True:
#     success, img = cap.read()

#     imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
#     results = faceDetection.process(imgRGB)
#     print(results)

#     if results.detections:
#         for id, detection in enumerate(results.detections):
#             # mpDraw.draw_detection(img, detection)
#             # print(id, detection)
#             # print(detection.score)
#             # print(detection.location_data.relative_bounding_box)
#             bboxC = detection.location_data.relative_bounding_box
#             ih, iw, ic = img.shape
#             bbox = int(bboxC.xmin * iw), int(bboxC.ymin * ih), \
#                    int(bboxC.width * iw), int(bboxC.height * ih)
#             cv2.rectangle(img, bbox, (255, 0, 255), 2)
#             cv2.putText(img, f'{int(detection.score[0] * 100)}%',
#                         (bbox[0], bbox[1] - 20), cv2.FONT_HERSHEY_PLAIN,
#                         2, (255, 0, 255), 2)

#     cTime = time.time()
#     fps = 1 / (cTime - pTime)
#     pTime = cTime
#     cv2.putText(img, f'FPS: {int(fps)}', (20, 70), cv2.FONT_HERSHEY_PLAIN,
#                 3, (0, 255, 0), 2)
#     cv2.imshow("Image", img)
#     cv2.waitKey(1)



import cv2
import mediapipe as mp
import time
import face_recognition
import os

def loadTrainingImages(path):
    images = []
    classNames = []
    myList = os.listdir(path)
    for cls in myList:
        currentImage = face_recognition.load_image_file(os.path.join(path,cls))
        images.append(currentImage)
        classNames.append(os.path.splitext(cls)[0])
        print("Loaded", cls, "Class Name", os.path.splitext(cls)[0])
    return images, classNames

path = r'C:\Users\RID\Desktop\ProjectFace\ABAN_FACERECOG\Live\faceimages4'
images, classNames = loadTrainingImages(path)
encodeListKnown = [face_recognition.face_encodings(img)[0] for img in images]

print("encoding complete")


cap = cv2.VideoCapture(1)
mpFaceDetection = mp.solutions.face_detection
faceDetection = mpFaceDetection.FaceDetection(0.75)


while True:
    success, img = cap.read()
    imgRGB = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    results = faceDetection.process(imgRGB)

    if results.detections:
        for id, detection in enumerate(results.detections):
            bboxC = detection.location_data.relative_bounding_box
            ih, iw, ic = img.shape
            bbox = int(bboxC.xmin * iw), int(bboxC.ymin * ih), \
                   int(bboxC.width * iw), int(bboxC.height * ih)
            
            # Recognize face using face_encodings
            encodeFace = face_recognition.face_encodings(img, [(bbox[1], bbox[2], bbox[1] + bbox[3], bbox[0] + bbox[2])])[0]
            matches = face_recognition.compare_faces(encodeListKnown, encodeFace, tolerance=0.7)
            name = "Unknown"  # Default name
            if True in matches:
                matchIndex = matches.index(True)
                name = classNames[matchIndex]
            print(name)
            cv2.rectangle(img, bbox, (255, 0, 255), 2)
            cv2.putText(img, name, (bbox[0], bbox[1]), cv2.FONT_HERSHEY_PLAIN,2, (255, 0, 255), 2)

    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()