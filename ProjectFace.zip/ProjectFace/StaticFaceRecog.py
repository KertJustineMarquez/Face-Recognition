# import cv2
# import numpy as np
# import face_recognition
# import os



# imgBill = face_recognition.load_image_file(r'C:\Users\RID\Desktop\ProjectFace\images\bill.jpeg')
# imgBill = cv2.cvtColor(imgBill, cv2.COLOR_BGR2RGB)

# faceLoc = face_recognition.face_locations(imgBill)[0]
# encodeBill = face_recognition.face_encodings(imgBill)[0]
# cv2.rectangle(imgBill, (faceLoc[3],faceLoc[0]), (faceLoc[1],faceLoc[2]),(255,0,255), 2)


# results = face_recognition.compare_faces([encodeBill], encodeBill)
# faceDis = face_recognition.face_distance([encodeBill], encodeBill)
# print(results, faceDis)

# # cv2.putText(imgBill, f'{results} {round(faceDis[0], 2)}',(50,50),cv2.FONT_HERSHEY_COMPLEX,1,(0,0,255),2)


# cv2.imshow("Bill", imgBill)

# cv2.waitKey(0)



# import cv2
# import face_recognition
# import os
# import numpy as np



# # Load and encode known images and names
# known_face_encodings = []
# known_face_names = []

# images_path = r'C:\Users\RID\Desktop\ProjectFace\faceimages2'
# # image_files = os.listdir(images_path)
# image_files = [f for f in os.listdir(images_path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]


# for image_file in image_files:
#     img_path = os.path.join(images_path, image_file)
#     img = face_recognition.load_image_file(img_path)
#     encode = face_recognition.face_encodings(img)[0]
#     known_face_encodings.append(encode)
    
#     # Get the name from the image file name
#     name = os.path.splitext(image_file)[0]
#     known_face_names.append(name)

# # Load the image you want to recognize
# imgBill = face_recognition.load_image_file(r'C:\Users\RID\Desktop\ProjectFace\faceimages2\GROUP.jpeg')
# imgBill = cv2.cvtColor(imgBill, cv2.COLOR_BGR2RGB)

# # Find the face in the loaded image
# faceLoc = face_recognition.face_locations(imgBill)[0]
# encodeBill = face_recognition.face_encodings(imgBill)[0]

# # Compare the face encoding with the known encodings
# results = face_recognition.compare_faces(known_face_encodings, encodeBill)
# faceDis = face_recognition.face_distance(known_face_encodings, encodeBill)
# match_index = np.argmin(faceDis)  # Index of the best match

# # Get the name of the recognized person
# if results[match_index]:
#     recognized_name = known_face_names[match_index]
# else:
#     recognized_name = "Unknown"

# # Draw rectangle and name on the image
# cv2.rectangle(imgBill, (faceLoc[3], faceLoc[0]), (faceLoc[1], faceLoc[2]), (255, 0, 255), 2)
# cv2.putText(imgBill, recognized_name, (50, 50), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)

# cv2.imshow("Bill", imgBill)
# cv2.waitKey(0)
# cv2.destroyAllWindows()


# import cv2
# import face_recognition
# import os
# import numpy as np

# # Load and encode known images and names
# known_face_encodings = []
# known_face_names = []

# images_path = r'C:\Users\RID\Desktop\ProjectFace\faceimages2'
# image_files = [f for f in os.listdir(images_path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

# for image_file in image_files:
#     img_path = os.path.join(images_path, image_file)
#     img = face_recognition.load_image_file(img_path)
#     # encode = face_recognition.face_encodings(img)[0]
#     face_encodingss = face_recognition.face_encodings(img)
#     # known_face_encodings.append(encode)
#     known_face_encodings.append(face_encodingss)

#     if len(face_encodingss) > 0:
#         encode = face_encodingss[0]
#         known_face_encodings.append(face_encodingss)

#      # Get the name from the image file name
#         name = os.path.splitext(image_file)[0]
#         known_face_names.append(name)
#     else:
#         print(f"No face detected in image: {image_file}")



# # Load the image you want to recognize
# imgBill = face_recognition.load_image_file(r'C:\Users\RID\Desktop\ProjectFace\faceimages2\GROUP.jpg')
# imgBill = cv2.cvtColor(imgBill, cv2.COLOR_BGR2RGB)

# # Find the faces in the loaded image
# face_locations = face_recognition.face_locations(imgBill)
# face_encodings = face_recognition.face_encodings(imgBill, face_locations)

# for (faceLoc, encodeBill) in zip(face_locations, face_encodings):
#     if len(encodeBill) > 0:
#         # Compare the face encoding with the known encodings
#         results = face_recognition.compare_faces(known_face_encodings, encodeBill)
#         faceDis = face_recognition.face_distance(known_face_encodings, encodeBill)
#         match_index = np.argmin(faceDis)  # Index of the best match

#         # Get the name of the recognized person
#         if results[match_index]:
#             recognized_name = known_face_names[match_index]
#         else:
#             recognized_name = "Unknown"

#         # Draw rectangle and name on the image
#         top, right, bottom, left = faceLoc
#         cv2.rectangle(imgBill, (left, top), (right, bottom), (255, 0, 255), 2)
#         cv2.putText(imgBill, recognized_name, (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
#     else:
#         print("No face detected in the image")
# cv2.imshow("Bill", imgBill)
# cv2.waitKey(0)
# cv2.destroyAllWindows()



import cv2
import face_recognition
import os
import numpy as np

# Load and encode known images and names
known_face_encodings = []
known_face_names = []

images_path = r'C:\Users\RID\Desktop\ProjectFace\faceimages'
image_files = [f for f in os.listdir(images_path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

for image_file in image_files:
    img_path = os.path.join(images_path, image_file)
    img = face_recognition.load_image_file(img_path)
    face_encodings = face_recognition.face_encodings(img)  # Get face encodings for all detected faces
    
    for face_encoding in face_encodings:
        known_face_encodings.append(face_encoding)
        
        if len(face_encoding) > 0:
            known_face_encodings.append(face_encoding)

            # Get the name from the image file name
            name = os.path.splitext(image_file)[0]
            known_face_names.append(name)
        else:
            print(f"No face detected in image: {image_file}")

# Load the image you want to recognize
imgBill = face_recognition.load_image_file(r'C:\Users\RID\Desktop\ProjectFace\faceimages2\GROUP2.jpg')
imgBill = cv2.cvtColor(imgBill, cv2.COLOR_BGR2RGB)

# Find the faces in the loaded image
face_locations = face_recognition.face_locations(imgBill)
face_encodings = face_recognition.face_encodings(imgBill, face_locations)

for (faceLoc, encodeBill) in zip(face_locations, face_encodings):
    # Compare the face encoding with the known encodings
    results = face_recognition.compare_faces(known_face_encodings, encodeBill)
    faceDis = face_recognition.face_distance(known_face_encodings, encodeBill)
    match_index = np.argmin(faceDis)  # Index of the best match

    # Get the name of the recognized person
    if results[match_index]:
        recognized_name = known_face_names[match_index]
    else:
        recognized_name = "Unknown"

    # Draw rectangle and name on the image
    top, right, bottom, left = faceLoc
    cv2.rectangle(imgBill, (left, top), (right, bottom), (255, 0, 255), 2)
    cv2.putText(imgBill, recognized_name, (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)

cv2.imshow("Bill", imgBill)
cv2.waitKey(0)
cv2.destroyAllWindows()
